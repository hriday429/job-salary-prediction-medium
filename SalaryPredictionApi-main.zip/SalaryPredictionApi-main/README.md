# SalaryPredictionApi

# Please Contribute in Dataset
- https://forms.gle/7LEMbsZ3VHbsmeRZ8

# Heroku Link
- https://intense-wave-80368.herokuapp.com/
# Health Check Api
- https://intense-wave-80368.herokuapp.com/api/health/
# Salary Prediction Api
https://intense-wave-80368.herokuapp.com/api/predict/

RequestBody:
```json
{
    "java": 7,
    "c#": 7,
    "python": 6,
    "c": 7,
    "c++": 6,
    "html": 7,
    "javascript": 4,
    "rubby": 0,
    "css": 1,
    "go": 0,
    "swift": 0,
    "php": 8,
    "kotlin": 0,
    "dart": 0
}
```