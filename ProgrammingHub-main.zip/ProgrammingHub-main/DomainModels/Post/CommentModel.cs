﻿namespace DomainModels.Post
{
    public class CommentModel
    {
        public string Comment { get; set; }
        public string PostId { get; set; }
    }
}